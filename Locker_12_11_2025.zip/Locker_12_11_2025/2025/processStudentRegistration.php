<?php
session_start();
include 'gijangovelockersystem.php';
include 'sessionManager.php';
requireLogin(['parent', 'admin']);
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: studentRegistration.php");
    exit;
}


$studentName    = trim($_POST['studentName'] ?? '');
$studentSurname = trim($_POST['studentSurname'] ?? '');
$studentGrade   = ucwords(strtolower(trim($_POST['studentGrade'] ?? '')));
$dateOfBirth    = $_POST['dateOfBirth'] ?? '';
$gender         = $_POST['gender'] ?? '';
$lockerID       = $_POST['lockerID'] ?? null;
$bookingDate    = $_POST['bookingDate'] ?? null;
$parentID       = ($_SESSION['userType'] === 'admin') ? ($_POST['parentID'] ?? null) : $_SESSION['userID'];

// it validate required fields
$errors = [];
if (!$studentName || !$studentSurname || !$dateOfBirth || !$gender || !$studentGrade || !$bookingDate || !$parentID) {
    $errors[] = "All fields are required.";
}

// it validate booking date
try {
    $bookingDateObj = new DateTime($bookingDate);
    $startDate = new DateTime('2026-01-01');
    $endDate   = new DateTime('2026-06-30');
    if ($bookingDateObj < $startDate || $bookingDateObj > $endDate) {
        $errors[] = "Booking date must be between January 1st and June 30th, 2026.";
    }
} catch (Exception $e) {
    $errors[] = "Invalid booking date format.";
}

// it validate grade
$validGrades = ['Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'];
if (!in_array($studentGrade, $validGrades)) {
    $errors[] = "Invalid grade selected.";
}

// it stop if there are validation errors
if (!empty($errors)) {
    $errorMsg = urlencode(implode(' ', $errors));
    header("Location: studentRegistration.php?error=$errorMsg");
    exit;
}

try {
    $pdo->beginTransaction();

    // to check for duplicate student
    $stmt = $pdo->prepare("SELECT studentID FROM students WHERE studentName = ? AND studentSurname = ? AND dateOfBirth = ? AND parentID = ?");
    $stmt->execute([$studentName, $studentSurname, $dateOfBirth, $parentID]);
    if ($stmt->fetchColumn()) {
        throw new Exception("This student is already registered.");
    }

    // to generate new student school number
    $lastStudent = $pdo->query("SELECT MAX(studentSchoolNumber) AS maxNumber FROM students")->fetch();
    $lastNumber = (int)($lastStudent['maxNumber'] ?? 0);
    $newSchoolNumber = str_pad($lastNumber + 1, 6, '0', STR_PAD_LEFT);


    // The grade quota check for limited grades
    $gradeQuota = ['Grade 8'=>10, 'Grade 9'=>null, 'Grade 10'=>null, 'Grade 11'=>null, 'Grade 12'=>5];
    $quota = $gradeQuota[$studentGrade] ?? null;
   
    if ($quota !== null) {
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT s.studentID) AS total
        FROM students s
        LEFT JOIN waitinglist w ON s.studentID = w.studentID AND w.status = 'Pending'
        LEFT JOIN bookings b ON s.studentID = b.studentID AND b.status = 'approved'
        WHERE s.studentGrade = ?
        FOR UPDATE
    ");
    $stmt->execute([$studentGrade]);
    $currentCount = (int)$stmt->fetchColumn();

    if ($currentCount >= $quota) {
        throw new Exception("Locker quota full for {$studentGrade}. No more applications are allowed for this grade.");
    }
}

    // to insert student
$stmt = $pdo->prepare("INSERT INTO students 
    (studentSchoolNumber, studentName, studentSurname, dateOfBirth, gender, studentGrade, parentID, lockerID)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
);
$stmt->execute([$newSchoolNumber, $studentName, $studentSurname, $dateOfBirth, $gender, $studentGrade, $parentID, $lockerID]);
$studentID = $pdo->lastInsertId();

    // this insert student into waiting list 
    $stmtWaiting = $pdo->prepare("INSERT INTO waitinglist (studentID, studentGrade, lockerID, dateAdded, status, type)
        VALUES (?, ?, ?, NOW(), 'Pending', 'Email')");
    $stmtWaiting->execute([$studentID, $studentGrade, $lockerID]);

    $status = 'waiting';
    $success = true;

    // it handle payment upload
    if ($_SESSION['userType'] === 'admin' && isset($_FILES['paymentProof']) && $_FILES['paymentProof']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/payments/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $filename = uniqid('proof_') . '_' . basename($_FILES['paymentProof']['name']);
        $targetPath = $uploadDir . $filename;
        move_uploaded_file($_FILES['paymentProof']['tmp_name'], $targetPath);

        $amount = 100.00;
        $stmt = $pdo->prepare("INSERT INTO payments (bookingID, amount, paymentDate, status, proofOfPayment) VALUES (?, ?, NOW(), 'pending', ?)");
        $stmt->execute([$bookingID ?? null, $amount, $targetPath]);
    }

    // Notifications
    $adminID = 1;
    $notificationMessage = "The student $studentName $studentSurname has been added to the locker waiting list.";

    $stmtNotif = $pdo->prepare("INSERT INTO notifications (parentID, adminID, type, message, dateSent, status, title)
        VALUES (?, ?, 'Email', ?, NOW(), 'pending', ?)");
    $stmtNotif->execute([$parentID, $adminID, $notificationMessage, 'Student added to waiting list']);

    // send emails
    $stmt = $pdo->prepare("SELECT parentEmailAddress FROM parents WHERE parentID = ?");
    $stmt->execute([$parentID]);
    $parentEmail = $stmt->fetchColumn();

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'vunenebasa@gmail.com';
        $mail->Password   = 'gtmj ytjl gkhi ftbb';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // email to parent
        $mail->setFrom('vunenebasa@gmail.com', 'Administrator');
        $mail->addAddress($parentEmail);
        $mail->isHTML(false);
        $mail->Subject = 'Student Registration Update';
        $mail->Body = "Dear Parent,\n\nYour child has been added to the waiting list for a locker.\n\nPlease submit payment via the portal.\n\nBest regards,\nGija-Ngove Locker System Administrator";
        $mail->send();

        // email to admin
        $mail->clearAddresses();
        $mail->addAddress('vunenebasa@gmail.com');
        $mail->Subject = 'New Student on Waiting List';
        $mail->Body = "Student: $studentName $studentSurname\nGrade: $studentGrade\nStatus: $status\n\nPlease review in administrator panel.";
        $mail->send();

    } catch (Exception $e) {
        error_log("Email error: " . $mail->ErrorInfo);
    }

    $pdo->commit();

    header("Location: studentInfo.php?registered=1&studentID=" . urlencode($studentID));
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo "<h2>Error</h2>";
    echo "<p style='color:red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<a href='studentRegistration.php'>Go Back</a>";
}
