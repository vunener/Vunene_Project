<?php
include 'sessionManager.php';
requireLogin('parent');

include 'gijangovelockersystem.php';

// to validate input
$studentID = isset($_GET['studentID']) ? (int)$_GET['studentID'] : 0;

if ($studentID <= 0) {
    header("Location: viewStudentInfo.php?error=invalid_id");
    exit;
}

try {
    // to confirm that student belongs to the logged-in parent
    $stmtCheck = $pdo->prepare("SELECT parentID FROM students WHERE studentID = ?");
    $stmtCheck->execute([$studentID]);
    $student = $stmtCheck->fetch(PDO::FETCH_ASSOC);

    if (!$student || (int)$student['parentID'] !== (int)$_SESSION['userID']) {
        header("Location: viewStudentInfo.php?error=unauthorized");
        exit;
    }

    // to delete student
    $stmtDelete = $pdo->prepare("DELETE FROM students WHERE studentID = ?");
    $stmtDelete->execute([$studentID]);

    header("Location: viewStudentInfo.php?deleted=1");
    exit;

} catch (PDOException $e) {
   
    header("Location: viewStudentInfo.php?error=db_error");
    exit;
}
