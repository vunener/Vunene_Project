-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: gijangovelockersystem
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `adminID` int(11) NOT NULL AUTO_INCREMENT,
  `adminUserName` varchar(50) DEFAULT NULL,
  `adminPassword` varchar(100) DEFAULT NULL,
  `role` varchar(30) DEFAULT NULL,
  `adminEmailAddress` varchar(100) DEFAULT NULL,
  `adminContactNum` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin1','$2y$10$RAiO4yFY/MKEl4hqbzWiwuwgnoN7wrh8b5RC22PEOsM2QlWaiKa4G','admin','admin1@gmail.com','0723433343'),(2,'admin2','$2y$10$RAiO4yFY/MKEl4hqbzWiwuwgnoN7wrh8b5RC22PEOsM2QlWaiKa4G','admin','admin2@gmail.com','0733433343');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `bookingID` int(11) NOT NULL AUTO_INCREMENT,
  `studentID` int(11) DEFAULT NULL,
  `lockerID` int(11) DEFAULT NULL,
  `status` enum('pending','approved','completed','rejected') NOT NULL DEFAULT 'pending',
  `bookingDate` date DEFAULT curdate(),
  `approvalDate` datetime DEFAULT NULL,
  `approvedByAdminID` int(11) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  PRIMARY KEY (`bookingID`),
  UNIQUE KEY `unique_student_locker` (`studentID`,`lockerID`),
  KEY `bookings_ibfk_2` (`lockerID`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE,
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`lockerID`) REFERENCES `lockers` (`lockerID`),
  CONSTRAINT `fk_booking_locker` FOREIGN KEY (`lockerID`) REFERENCES `lockers` (`lockerID`) ON DELETE SET NULL,
  CONSTRAINT `fk_booking_student` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE,
  CONSTRAINT `fk_locker` FOREIGN KEY (`lockerID`) REFERENCES `lockers` (`lockerID`) ON DELETE CASCADE,
  CONSTRAINT `fk_student` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (145,104,72,'completed','2025-10-08','2025-10-08 09:45:36',1,'Your booking is pending approval.'),(146,105,73,'completed','2025-10-08','2025-10-08 14:02:07',1,'Your booking is pending approval.'),(147,106,74,'completed','2025-10-08','2025-10-08 15:00:57',1,'Your booking is pending approval.'),(148,107,75,'completed','2025-10-08','2025-10-08 15:31:57',1,'Your booking is pending approval.'),(149,108,76,'completed','2025-10-08','2025-10-08 16:15:36',1,'Your booking is pending approval.'),(150,109,77,'completed','2025-10-10','2025-10-10 15:37:28',1,'Your booking is pending approval.');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lockers`
--

DROP TABLE IF EXISTS `lockers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lockers` (
  `lockerID` int(11) NOT NULL AUTO_INCREMENT,
  `studentGrade` varchar(10) DEFAULT NULL,
  `lockerNumber` varchar(50) DEFAULT NULL,
  `lockerLocation` enum('Top','Middle','Bottom') NOT NULL,
  `availability` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`lockerID`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lockers`
--

LOCK TABLES `lockers` WRITE;
/*!40000 ALTER TABLE `lockers` DISABLE KEYS */;
INSERT INTO `lockers` VALUES (72,'Grade 8','L01','Top',1),(73,'Grade 8','L02','Top',1),(74,'Grade 8','L03','Top',1),(75,'Grade 8','L04','Top',1),(76,'Grade 12','L05','Top',1),(77,'Grade 11','L06','Top',1),(78,NULL,'L07','Top',0),(79,NULL,'L08','Top',0),(80,NULL,'L09','Top',0),(81,NULL,'L10','Top',0),(82,NULL,'L11','Top',0),(83,NULL,'L12','Top',0),(84,NULL,'L13','Top',0),(85,NULL,'L14','Top',0),(86,NULL,'L15','Top',0),(87,NULL,'L16','Top',0),(88,NULL,'L17','Top',0),(89,NULL,'L18','Top',0),(90,NULL,'L19','Top',0),(91,NULL,'L20','Top',0),(92,NULL,'L21','Top',0),(93,NULL,'L22','Top',0),(94,NULL,'L23','Top',0),(95,NULL,'L24','Top',0),(96,NULL,'L25','Top',0),(97,NULL,'L26','Middle',0),(98,NULL,'L27','Middle',0),(99,NULL,'L28','Middle',0),(100,NULL,'L29','Middle',0),(101,NULL,'L30','Middle',0),(102,NULL,'L31','Middle',0),(103,NULL,'L32','Middle',0),(104,NULL,'L33','Middle',0),(105,NULL,'L34','Middle',0),(106,NULL,'L35','Middle',0),(107,NULL,'L36','Middle',0),(108,NULL,'L37','Middle',0),(109,NULL,'L38','Middle',0),(110,NULL,'L39','Middle',0),(111,NULL,'L40','Middle',0),(112,NULL,'L41','Middle',0),(113,NULL,'L42','Middle',0),(114,NULL,'L43','Middle',0),(115,NULL,'L44','Middle',0),(116,NULL,'L45','Middle',0),(117,NULL,'L46','Middle',0),(118,NULL,'L47','Middle',0),(119,NULL,'L48','Middle',0),(120,NULL,'L49','Middle',0),(121,NULL,'L50','Middle',0),(122,NULL,'L51','Bottom',0),(123,NULL,'L52','Bottom',0),(124,NULL,'L53','Bottom',0),(125,NULL,'L54','Bottom',0),(126,NULL,'L55','Bottom',0),(127,NULL,'L56','Bottom',0),(128,NULL,'L57','Bottom',0),(129,NULL,'L58','Bottom',0),(130,NULL,'L59','Bottom',0),(131,NULL,'L60','Bottom',0),(132,NULL,'L61','Bottom',0),(133,NULL,'L62','Bottom',0),(134,NULL,'L63','Bottom',0),(135,NULL,'L64','Bottom',0),(136,NULL,'L65','Bottom',0),(137,NULL,'L66','Bottom',0),(138,NULL,'L67','Bottom',0),(139,NULL,'L68','Bottom',0),(140,NULL,'L69','Bottom',0),(141,NULL,'L70','Bottom',0),(142,NULL,'L71','Bottom',0),(143,NULL,'L72','Bottom',0),(144,NULL,'L73','Bottom',0),(145,NULL,'L74','Bottom',0),(146,NULL,'L75','Bottom',0);
/*!40000 ALTER TABLE `lockers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `notificationID` int(11) NOT NULL AUTO_INCREMENT,
  `parentID` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `adminID` int(11) NOT NULL,
  `type` enum('phone number','Email') NOT NULL,
  `message` text NOT NULL,
  `status` enum('available','pending','completed','rejected') DEFAULT 'pending',
  `dateSent` datetime DEFAULT NULL,
  PRIMARY KEY (`notificationID`),
  KEY `notifications_ibfk_1` (`parentID`),
  KEY `notifications_ibfk_2` (`adminID`),
  CONSTRAINT `fk_admin` FOREIGN KEY (`adminID`) REFERENCES `admins` (`adminID`) ON DELETE CASCADE,
  CONSTRAINT `fk_parent` FOREIGN KEY (`parentID`) REFERENCES `parents` (`parentID`) ON DELETE CASCADE,
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`parentID`) REFERENCES `parents` (`parentID`) ON DELETE CASCADE,
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`adminID`) REFERENCES `admins` (`adminID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (136,76,'Student Added to Waiting List',1,'Email','Your child Nthavi Maswanganye has been added to the locker waiting list.','completed','2025-10-08 09:39:19'),(137,76,NULL,1,'','Payment #62 confirmed','pending','2025-10-08 09:48:28'),(138,76,'Student Added to Waiting List',1,'Email','Your child Ntombinyana Maswanganye has been added to the locker waiting list.','completed','2025-10-08 13:58:40'),(139,76,NULL,1,'','Your application was successful. Please make a payment of R100.','','2025-10-08 14:01:19'),(140,76,NULL,1,'','Payment #63 confirmed','pending','2025-10-08 14:23:32'),(141,76,NULL,1,'','Payment #64 confirmed','pending','2025-10-08 14:23:43'),(142,76,'Student Added to Waiting List',1,'Email','Your child YInhleni Maswanganye has been added to the locker waiting list.','completed','2025-10-08 14:57:16'),(143,76,'Student Added to Waiting List',1,'Email','Your child Tsiki Maswanganye has been added to the locker waiting list.','pending','2025-10-08 15:28:21'),(144,76,NULL,1,'','Your application was successful. Please make a payment of R100.','','2025-10-08 15:30:09'),(145,76,NULL,1,'','Payment #66 confirmed','pending','2025-10-08 15:32:17'),(146,76,'Student Added to Waiting List',1,'Email','Your child Vestoer Maswanganye has been added to the locker waiting list.','pending','2025-10-08 16:11:33'),(147,76,NULL,1,'','Payment #67 confirmed','pending','2025-10-08 16:15:53'),(148,76,NULL,1,'','Payment #67 confirmed','pending','2025-10-08 16:17:23'),(149,76,'Student Added to Waiting List',1,'Email','Your child Thandy Maswanganye has been added to the locker waiting list.','pending','2025-10-10 15:33:59');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parents`
--

DROP TABLE IF EXISTS `parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parents` (
  `parentID` int(11) NOT NULL AUTO_INCREMENT,
  `parentTitle` varchar(10) DEFAULT NULL,
  `parentIDNumber` varchar(20) DEFAULT NULL,
  `parentName` varchar(50) DEFAULT NULL,
  `parentSurname` varchar(50) DEFAULT NULL,
  `parentEmailAddress` varchar(100) DEFAULT NULL,
  `parentPhoneNumber` varchar(20) DEFAULT NULL,
  `parentHomeAddress` text DEFAULT NULL,
  `parentUsername` varchar(50) DEFAULT NULL,
  `parentPassword` varchar(100) DEFAULT NULL,
  `preferredNotification` varchar(50) DEFAULT 'Email',
  `dateCreated` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`parentID`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parents`
--

LOCK TABLES `parents` WRITE;
/*!40000 ALTER TABLE `parents` DISABLE KEYS */;
INSERT INTO `parents` VALUES (1,'Mr','7110115033116','Joe','Smith','joe.smith@gmail.com','0821234567','123 Maple St','jsmith','jsmith$1234','Email','2025-06-20 10:24:33'),(2,'Mrs','7903018701182','Mary','Johnson','mary.johnson@gmail.com','0832345678','456 Oak Ave','mjohnson','mjohnson$2345','Email','2025-06-20 10:24:33'),(3,'Ms','9504200125035','Linda','Brown','linda.brown@gmail.com','0843456789','789 Pine Rd','lbrown','$2y$10$qWGh.LtjbxKAnUxi.ptF6urtls/xJ7tSI8l/r/hGQ80GQPB8HJqPi','Email','2025-06-20 10:24:33'),(4,'Mr','9411277787016','David','Johnson','david.johnson@gmail.com','0745678901','321 Maple Lane','djohnson','djohnson$5678','Email','2025-06-20 10:24:33'),(5,'Mrs','9298654199120','Emma','Wilson','emma.wilson@gmail.com','0756789012','654 Cedar Drive','ewilson1','ewilson$6789','Email','2025-06-20 10:24:33'),(6,'Dr','9212011817041','Robert','Taylor','robert.taylor@gmail.com','0767890123','987 Birch Boulevard','rtaylor1','rtaylor$7890','Email','2025-06-20 10:24:33'),(7,'Ms','5004038523192','Linda','Anderson','linda.anderson@gmail.com','0778901234','135 Spruce Street','landerson1','landerson$8901','Email','2025-06-20 10:24:33'),(8,'Mr','4109137427178','James','Thomas','james.thomas@gmail.com','0789012345','246 Redwood Court','jthomas','jthomas$9012','Email','2025-06-20 10:24:33'),(9,'Mrs','5612226663035','Robert','Wilson','robert.wilson@gmail.com','0735460310','189 Pine Street','rwilson','$2y$10$HEwPvZyqPwQm.If5wcbl4.Bh5ebibu8kOY2KuJNETZySsN/IndRMa','Email','2025-06-20 10:24:33'),(10,'Mr','9101073547175','Michael','Anderson','michael.anderson@gmail.com','0775510858','702 Maple Street','manderson','manderson$5510','Email','2025-06-20 10:24:33'),(11,'Ms','4207012946087','Emma','Smith','emma.smith@gmail.com','0749100605','718 Ash Street','esmith','esmith$9100','Email','2025-06-20 10:24:33'),(12,'Mrs','8305068147131','Ava','Smith','ava.smith@gmail.com','0783072551','599 Spruce Street','asmith1','asmith$3072','Email','2025-06-20 10:24:33'),(13,'Mr','9505017498148','Ava','Hall','ava.hall@gmail.com','0791798774','332 Maple Street','ahall','ahall$1798','Email','2025-06-20 10:24:33'),(14,'Ms','6602050571067','Liam','White','liam.white@gmail.com','0737988829','842 Birch Street','lwhite','lwhite$7988','Email','2025-06-20 10:24:33'),(15,'Mrs','9012129123195','Noah','Hall','noah.hall@gmail.com','0743682129','190 Willow Street','nhall','nhall$3682','Email','2025-06-20 10:24:33'),(16,'Dr','7306052541142','Easter','Anderson','easter.anderson@gmail.com','0721206388','704 Willow Street','eanderson','eanderson$1206','Email','2025-06-20 10:24:33'),(17,'Ms','9507203452020','Robert','Anderson','robert.anderson@gmail.com','0739094911','875 Maple Street','randerson','randerson$9094','Email','2025-06-20 10:24:33'),(18,'Mr','6806020888197','Michael','Nkosi','michael.nkosi@gmail.com','0798801632','897 Cedar Street','mnkosi','mnkosi$8801','Email','2025-06-20 10:24:33'),(19,'Dr','7807275046086','Liam','Brown','liam.brown@gmail.com','0786828544','492 Spruce Street','lbrown1','lbrown$6828','Email','2025-06-20 10:24:33'),(20,'Dr','4809209872196','Robert','Smith','robert.smith@gmail.com','0768346836','757 Cedar Street','rsmith','rsmith$8346','Email','2025-06-20 10:24:33'),(21,'Mrs','4204287904104','Liam','Nkosi','liam.nkosi@gmail.com','0744083306','433 Birch Street','lnkosi','lnkosi$4083','Email','2025-06-20 10:24:33'),(22,'Dr','7612064343182','Oska','Nkosi','oska.nkosi@gmail.com','0752005034','852 Cedar Street','onkosi','onkosi$2005','Email','2025-06-20 10:24:33'),(23,'Ms','4809018674075','Rose','Taylor','rose.taylor@gmail.com','0743877000','162 Ash Street','rtaylor','rtaylor$3877','Email','2025-06-20 10:24:33'),(24,'Mr','5707284141112','Liam','Anderson','liam.anderson@gmail.com','0796115093','327 Redwood Street','landerson','landerson$6115','Email','2025-06-20 10:24:33'),(25,'Mr','7009119979038','Ava','Wilson','ava.wilson@gmail.com','0764281373','911 Birch Street','awilson1','awilson$4281','Email','2025-06-20 10:24:33'),(26,'Mrs','5106123937064','Alice','Smith','alice.smith@gmail.com','0759764000','447 Birch Street','asmith','asmith$9764','Email','2025-06-20 10:24:33'),(27,'Dr','4510283636054','Noah','White','noah.white@gmail.com','0777393801','604 Pine Street','nwhite','nwhite$7393','Email','2025-06-20 10:24:33'),(28,'Ms','8502022675077','Jane','Anderson','jane.anderson@gmail.com','0758356276','431 Spruce Street','janderson','janderson$8356','Email','2025-06-20 10:24:33'),(29,'Dr','4409125431129','John','Nkosi','john.nkosi@gmail.com','0799536039','436 Elm Street','jnkosi','jnkosi$9536','Email','2025-06-20 10:24:33'),(30,'Ms','6305123394192','Easter','Johnson','easter.johnson@gmail.com','0763177499','715 Birch Street','ejohnson','ejohnson$3177','Email','2025-06-20 10:24:33'),(31,'Mr','5912127358130','Michael','White','michael.white@gmail.com','0743043868','238 Oak Street','mwhite','mwhite$3043','Email','2025-06-20 10:24:33'),(32,'Mrs','6603287420165','Sophia','Hall','sophia.hall@gmail.com','0778621486','776 Cedar Street','shall','shall$8621','Email','2025-06-20 10:24:33'),(33,'Mr','6012217265129','Joe','Nkosi','joe.nkosi@gmail.com','0728680821','600 Elm Street','jnkosi1','jnkosi$8680','Email','2025-06-20 10:24:33'),(34,'Ms','9602046538016','Ava','Thomas','ava.thomas@gmail.com','0711846135','446 Redwood Street','athomas','athomas$1846','Email','2025-06-20 10:24:33'),(35,'Dr','7303154126003','Ethan','Taylor','ethan.taylor@gmail.com','0799314784','404 Oak Street','etaylor','etaylor$9314','Email','2025-06-20 10:24:33'),(36,'Ms','8202019503196','Jane','Taylor','jane.taylor@gmail.com','0781998910','911 Ash Street','jtaylor','jtaylor$1998','Email','2025-06-20 10:24:33'),(37,'Mrs','5512102556093','Liam','Wilson','liam.wilson@gmail.com','0748585981','413 Ash Street','lwilson','lwilson$8585','Email','2025-06-20 10:24:33'),(38,'Mr','9309202925129','Liam','Smith','liam.smith@gmail.com','0742749180','310 Maple Street','lsmith','lsmith$2749','Email','2025-06-20 10:24:33'),(39,'Mrs','8809035978098','John','Smith','john.smith@gmail.com','0775223322','140 Maple Street','jsmith1','jsmith$5223','Email','2025-06-20 10:24:33'),(40,'Ms','9912089374198','Sulphina','Hall','sulphina.hall@gmail.com','0777667807','661 Maple Street','shall1','shall$7667','Email','2025-06-20 10:24:33'),(41,'Dr','6705260699127','Donald','Johnson','donald.johnson@gmail.com','0784780625','473 Birch Street','djohnson1','djohnson$4780','Email','2025-06-20 10:24:33'),(42,'Mr','8008113111123','Albert','Wilson','albert.wilson@gmail.com','0737248373','636 Cedar Street','awilson','awilson$7248','Email','2025-06-20 10:24:33'),(43,'Mr','8912266784015','Noah','Nkosi','noah.nkosi@gmail.com','0763407066','353 Oak Street','nnkosi','nnkosi$3407','Email','2025-06-20 10:24:33'),(44,'Mrs','4803233540087','Ethel','Nkosi','ethel.nkosi@gmail.com','0722944641','336 Willow Street','enkosi1','enkosi$2944','Email','2025-06-20 10:24:33'),(45,'Mr','9501303848045','Evra','Wilson','evra.wilson@gmail.com','0714946067','487 Spruce Street','ewilson2','ewilson$4946','Email','2025-06-20 10:24:33'),(46,'Mr','6711189204048','Ethan','Nkosi','ethan.nkosi@gmail.com','0738510987','382 Elm Street','enkosi','enkosi$8510','Email','2025-06-20 10:24:33'),(47,'Mrs','6301209154077','Olivia','Hall','olivia.hall@gmail.com','0717403055','864 Cedar Street','ohall','ohall$7403','Email','2025-06-20 10:24:33'),(48,'Mrs','7811225151184','Emma','Johnson','emma.johnson@gmail.com','0787978403','483 Oak Street','ejohnson1','ejohnson$7978','Email','2025-06-20 10:24:33'),(49,'Dr','4608148192183','John','Anderson','john.anderson@gmail.com','0777769694','789 Willow Street','janderson1','janderson$7769','Email','2025-06-20 10:24:33'),(50,'Mr','6204032653193','Michael','Taylor','michael.taylor@gmail.com','0721216884','701 Spruce Street','mtaylor','mtaylor$1216','Email','2025-06-20 10:24:33'),(51,'Dr','4901218928125','Michael','Thomas','michael.thomas@gmail.com','0711790361','104 Elm Street','mthomas','mthomas$1790','Email','2025-06-20 10:24:33'),(52,'Mrs','5206163043195','David','Taylor','david.taylor@gmail.com','0749909129','744 Maple Street','dtaylor','dtaylor$9909','Email','2025-06-20 10:24:33'),(53,'Ms','9108286769008','Noah','Taylor','noah.taylor@gmail.com','0787273081','566 Ash Street','ntaylor','ntaylor$7273','Email','2025-06-20 10:24:33'),(54,'Ms','4708037500102','Ethan','Wilson','ethan.wilson@gmail.com','0718425293','500 Birch Street','ewilson','ewilson$8425','Email','2025-06-20 10:24:33'),(55,'Mr','4609139102037','Obert','Smith','obert.smith@gmail.com','0763380717','216 Oak Street','osmith','$2y$10$5D6GhflsQY69FZWBA15CSOSqCVZ442KpN28fc4CZZDTr4RlV8iMOC','Email','2025-06-20 10:24:33'),(56,'Ms','6104301288034','Emily','Brown','emily.brown@gmail.com','0719919743','906 Oak Street','ebrown','ebrown$9919','Email','2025-06-20 10:24:33'),(57,'Dr','8612145459128','Rudolph','Anderson','rudolph.anderson@gmail.com','0764100813','991 Redwood Street','randerson1','randerson$4100','Email','2025-06-20 10:24:33'),(58,'Mr','4108192658003','Olivia','Anderson','olivia.anderson@gmail.com','0714962168','404 Cedar Street','oanderson','oanderson$4962','Email','2025-06-20 10:24:33'),(59,'Mr','8211122255055','Robert','Nkuna','robert.nkuna@gmail.com','0794962169','661 Oak Street','rnkuna','rnkuna$4962','Email','2025-06-20 10:24:33'),(60,'Mr','8108192658004','William','Smith','william.smith@gmail.com','0724962110','545 Via Street','wsmith','wsmith$4962','Email','2025-06-20 10:24:33'),(61,'Mrs','8208192658005','Mercy','Khumalo','mercy.khumalo@gmail.com','0734962121','767 Watlo Street','mkhumalo','mkhumalo$4962','Email','2025-06-20 10:24:33'),(62,'Dr','8408192658006','Sizwe','Vuma','sizwe.vuma@gmail.com','0744962132','456 Christ Street','svuma','svuma$4962','Email','2025-06-20 10:24:33'),(63,'Prof','7808192658007','Hlulani','Mabunda','hlulani.mabunda@gmail.com','0754962143','565 Emelo Street','hmabunda','hmabunda$4962','Email','2025-06-20 10:24:33'),(64,'Mr','7108192658008','Stephen','Ngobeni','stephen.ngobeni@gmail.com','0714962154','787 Giy Street','sngobeni','sngobeni$4962','Email','2025-06-20 10:24:33'),(65,'Mrs','7308192658009','Wendy','Hlungwane','wendy.hlungwane@gmail.com','0764962165','345 House Street','whlungwane','whlungwane$4962','Email','2025-06-20 10:24:33'),(66,'Ms','7408192658010','Ntombi','Sithebe','ntombi.sithebe@gmail.com','0774962177','555 Lou Street','nsithebe','nsithebe$4962','Email','2025-06-20 10:24:33'),(67,'Mr','6908192658011','Thabang ','Sithole','thabang.sithole@gmail.com','0784962187','245 Key Street','tsithole','tsithole$4962','Email','2025-06-20 10:24:33'),(68,'Dr','7208192658012','Kenneth','Maluleke','kenneth.maluleke@gmail.com','0764962198','623 Teka Street','kmaluleke','kmaluleke$4962','Email','2025-06-20 10:24:33'),(69,'Dr','7708192658013','Kingston','Mahlaule','kingston.mahlaule@gmail.com','0724962112','222 Kuma Street','kmahlaule','kmahlaule$4962','Email','2025-06-20 10:24:33'),(74,'Mrs','8301077788082','Tiyani','Nkuna','yinhlanthavela@gmail.com','0726541526','85 Standstand street, Centurion','Tiyani','$2y$10$HIyxy29umFq23uvtf8QMkODfaT60XcxhQVxjTICSB4yzL.snhHp/O','Email','2025-09-10 13:22:30'),(76,'Mr','9003155588001','Mondi','Maswanganye','yinhlanthavela@gmail.com','0733984629','Success Steet, Highveld, Centurion 0157\r\nTurnhouse Steet, Highveld, Centurion 0157','Mondi','$2y$10$95RbWGOjWrwpnqKKEHD6Ee3z7wI2AiDmlRu2tnaV/HXc37zLeeJyu','Email','2025-10-02 21:39:51'),(77,'Mrs','8501011234089','Alice Smith',NULL,'yinhlanthavela@gmail.com','0711223344','45 Oak Street','alicesmith','vrm001','email','2025-10-03 21:34:51');
/*!40000 ALTER TABLE `parents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `paymentID` int(11) NOT NULL AUTO_INCREMENT,
  `bookingID` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 340.00,
  `paymentDate` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('available','pending','completed','rejected') DEFAULT 'pending',
  `proofOfPayment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`paymentID`),
  KEY `payments_ibfk_1` (`bookingID`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`bookingID`) REFERENCES `bookings` (`bookingID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (63,145,100.00,'2025-10-08 13:52:18','completed','uploads/proof_68e65072049cf.pdf'),(64,146,100.00,'2025-10-08 14:13:22','completed','uploads/proof_68e65562c5baa.pdf'),(65,147,100.00,'2025-10-08 15:00:19','completed','uploads/proof_68e660637d866.pdf'),(66,148,100.00,'2025-10-08 15:31:05','completed','uploads/proof_68e6679916b6b.pdf'),(67,149,100.00,'2025-10-10 16:01:11','completed','uploads/proof_68e911a76a91d.pdf'),(68,150,100.00,'2025-10-10 15:40:48','completed','uploads/proof_68e90ce002aa1.pdf');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `studentID` int(11) NOT NULL AUTO_INCREMENT,
  `studentSchoolNumber` char(6) DEFAULT NULL,
  `studentName` varchar(50) DEFAULT NULL,
  `studentSurname` varchar(50) DEFAULT NULL,
  `dateOfBirth` date DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `studentGrade` varchar(20) DEFAULT NULL,
  `parentID` int(11) DEFAULT NULL,
  `lockerID` int(11) DEFAULT NULL,
  PRIMARY KEY (`studentID`),
  UNIQUE KEY `unique_school_number` (`studentSchoolNumber`),
  KEY `parentID` (`parentID`),
  KEY `fk_students_lockerID` (`lockerID`),
  CONSTRAINT `fk_students_lockerID` FOREIGN KEY (`lockerID`) REFERENCES `lockers` (`lockerID`) ON DELETE SET NULL,
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`parentID`) REFERENCES `parents` (`parentID`),
  CONSTRAINT `chk_school_number_format` CHECK (`studentSchoolNumber` regexp '^[0-9]{6}$')
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'510010','Emma','Smith','2010-04-12','Female','Grade 9',1,NULL),(2,'357874','Liam','Johnson','2011-01-20','Male','Grade 8',2,NULL),(3,'550037','Olivia','Brown','2009-07-05','Female','Grade 10',3,NULL),(4,'217985','Leem','Johnson','2009-11-30','Male','Grade 10',4,NULL),(5,'110216','Olivia','Wilson','2010-03-25','Female','Grade 9',5,NULL),(6,'764982','Noah','Taylor','2011-06-17','Male','Grade 9',6,NULL),(7,'200443','Ava','Anderson','2008-08-03','Female','Grade 11',7,NULL),(8,'910983','Ethan','Thomas','2009-09-14','Male','Grade 10',8,NULL),(9,'390412','James','Wilson','2010-10-10','Male','Grade 9',9,NULL),(10,'878977','Noah','Anderson','2010-05-19','Male','Grade 9',10,NULL),(11,'558556','Liam','Smith','2009-02-23','Male','Grade 10',11,NULL),(12,'317750','Ava','Smith','2009-12-15','Female','Grade 10',12,NULL),(13,'453633','Emily','Hall','2011-01-18','Female','Grade 9',13,NULL),(14,'611784','Jane','White','2011-04-22','Female','Grade 9',14,NULL),(15,'582349','John','Hall','2009-11-02','Male','Grade 10',15,NULL),(16,'528034','Jane','Anderson','2008-07-09','Female','Grade 11',16,NULL),(17,'173463','Michael','Anderson','2010-01-12','Male','Grade 9',17,NULL),(18,'287868','David','Nkosi','2011-10-27','Male','Grade 9',18,NULL),(19,'908979','Emily','Brown','2009-06-29','Female','Grade 10',19,NULL),(20,'271520','Alice','Smith','2011-03-14','Female','Grade 9',20,NULL),(21,'720053','Jane','Nkosi','2009-08-08','Female','Grade 10',21,NULL),(22,'761953','Sophia','Nkosi','2009-09-30','Female','Grade 10',22,NULL),(23,'916977','James','Taylor','2010-11-05','Male','Grade 9',23,NULL),(24,'407505','Emily','Anderson','2010-06-13','Female','Grade 9',24,NULL),(25,'652308','Michael','Wilson','2009-05-07','Male','Grade 10',25,NULL),(26,'312754','Leey','Smith','2009-07-01','Male','Grade 10',26,NULL),(27,'801075','Ava','White','2008-09-12','Female','Grade 11',27,NULL),(28,'825753','Ethan','Anderson','2011-02-20','Male','Grade 9',28,NULL),(29,'739637','John','Nkosi','2010-06-18','Male','Grade 9',29,NULL),(30,'902543','Alice','Johnson','2008-04-25','Female','Grade 11',30,NULL),(31,'749847','Robert','White','2010-11-10','Male','Grade 9',31,NULL),(32,'611591','Liam','Hall','2011-05-14','Male','Grade 9',32,NULL),(33,'899951','Liam','Nkosi','2011-08-22','Male','Grade 8',33,NULL),(34,'264399','Robert','Thomas','2011-12-02','Male','Grade 8',34,NULL),(35,'509342','Olivia','Taylor','2011-07-30','Female','Grade 9',35,NULL),(36,'895067','Alice','Taylor','2010-01-19','Female','Grade 9',36,NULL),(37,'828859','Ethan','Wilson','2007-06-06','Male','Grade 12',37,NULL),(38,'628670','Ethan','Smith','2009-03-03','Male','Grade 10',38,NULL),(39,'508534','Emmar','Smith','2009-09-09','Female','Grade 10',39,NULL),(40,'773539','Johnnes','Hall','2011-04-17','Male','Grade 8',40,NULL),(41,'617741','Olive','Johnson','2007-11-11','Female','Grade 12',41,NULL),(42,'647927','Alice','Wilson','2007-10-20','Female','Grade 12',42,NULL),(43,'277788','Olivia','Nkosi','2009-06-05','Female','Grade 10',43,NULL),(44,'382254','Michael','Nkosi','2011-01-07','Male','Grade 9',44,NULL),(45,'163680','Emmara','Wilson','2011-09-21','Female','Grade 8',45,NULL),(46,'248256','Liamme','Nkosi','2009-02-14','Male','Grade 10',46,NULL),(47,'582399','Jammy','Hall','2011-05-25','Male','Grade 10',47,NULL),(48,'567866','Oliviaser','Johnson','2010-08-08','Female','Grade 9',48,NULL),(49,'977032','Jameson','Anderson','2008-03-13','Male','Grade 11',49,NULL),(50,'762563','Johanson','Taylor','2008-12-28','Male','Grade 11',50,NULL),(51,'922628','Sophiar','Thomas','2010-10-16','Female','Grade 9',51,NULL),(52,'221375','Ava','Taylor','2008-07-17','Female','Grade 11',52,NULL),(53,'540787','Sophia','Taylor','2011-06-11','Female','Grade 9',53,NULL),(54,'309568','Jane','Wilson','2010-02-09','Female','Grade 9',54,NULL),(55,'801734','Olivia','Smith','2007-05-15','Female','Grade 12',55,NULL),(56,'868018','James','Brown','2009-11-30','Male','Grade 10',56,NULL),(57,'694925','Ava','Anderson','2008-04-02','Female','Grade 11',57,NULL),(58,'366289','Liam','Anderson','2010-09-05','Male','Grade 9',58,NULL),(59,'376289','Lee','Nkuna','2009-01-03','Male','Grade 10',59,NULL),(60,'386289','Leam','Smith','2008-08-19','Male','Grade 11',60,NULL),(61,'396289','Ntando','Khumalo','2008-10-10','Male','Grade 11',61,NULL),(62,'310289','Wam ','Vuma','2010-03-01','Male','Grade 9',62,NULL),(63,'311289','Nko','Mabunda','2010-06-26','Male','Grade 9',63,NULL),(64,'312289','Tab','Ngobeni','2008-11-13','Male','Grade 11',64,NULL),(65,'313289','Dima','Hlungwane','2007-04-04','Female','Grade 12',65,NULL),(66,'314289','Sandile','Sithebe','2008-01-27','Male','Grade 11',66,NULL),(67,'315289','Lisedi','Sithole','2010-07-23','Female','Grade 9',67,NULL),(68,'316289','Hluma','Maluleke','2008-06-06','Female','Grade 11',68,NULL),(69,'317289','Hole','Mahlaule','2008-12-15','Female','Grade 11',69,NULL),(73,'520010','Liam','Smith','2011-09-25','Male','Grade 8',15,NULL),(104,'977033','Nthavi','Maswanganye','2011-06-14','Female','Grade 8',76,72),(105,'977034','Ntombinyana','Maswanganye','2011-06-14','Male','Grade 8',76,73),(106,'977035','YInhleni','Maswanganye','2011-06-14','Male','Grade 8',76,74),(107,'977036','Tsiki','Maswanganye','2011-06-14','Male','Grade 8',76,75),(108,'977037','Vestoer','Maswanganye','2008-03-14','Male','Grade 12',76,76),(109,'977038','Thandy','Maswanganye','2008-03-14','Female','Grade 11',76,77);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `waitinglist`
--

DROP TABLE IF EXISTS `waitinglist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `waitinglist` (
  `waitingID` int(11) NOT NULL AUTO_INCREMENT,
  `studentID` int(11) NOT NULL,
  `studentGrade` enum('Grade 8','Grade 9','Grade 10','Grade 11','Grade 12') NOT NULL,
  `dateAdded` date NOT NULL DEFAULT curdate(),
  `status` enum('Pending','Approved','Cancelled','Completed','Regret') NOT NULL DEFAULT 'Pending',
  `type` enum('Phone','Email') NOT NULL DEFAULT 'Email',
  `lockerID` int(11) DEFAULT NULL,
  PRIMARY KEY (`waitingID`),
  KEY `fk_waitinglist_studentID` (`studentID`),
  CONSTRAINT `fk_waitinglist_studentID` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE,
  CONSTRAINT `waitinglist_ibfk_1` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waitinglist`
--

LOCK TABLES `waitinglist` WRITE;
/*!40000 ALTER TABLE `waitinglist` DISABLE KEYS */;
INSERT INTO `waitinglist` VALUES (47,104,'Grade 8','2025-10-08','Completed','Email',72),(48,105,'Grade 8','2025-10-08','Completed','Email',73),(49,106,'Grade 8','2025-10-08','Completed','Email',74),(50,107,'Grade 8','2025-10-08','Completed','Email',75),(51,108,'','2025-10-08','Completed','Email',76),(52,109,'Grade 11','2025-10-10','Completed','Email',77);
/*!40000 ALTER TABLE `waitinglist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-12 14:04:11
