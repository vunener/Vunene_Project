<?php
require_once 'sessionManager.php';
requireLogin(['admin']);
require_once 'gijangovelockersystem.php';
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$adminID = $_SESSION['userID'] ?? null;
$bookingID = isset($_GET['bookingID']) ? (int)$_GET['bookingID'] : 0;
$action = $_GET['action'] ?? '';

if (!$bookingID || !in_array($action, ['approve', 'reject'], true)) {
    die('Invalid request.');
}

try {
    // to fetch booking, student, parent, and locker info
    $stmt = $pdo->prepare("SELECT b.bookingID, b.bookingDate, s.studentName, s.studentSurname, s.studentID, s.lockerID, p.parentID, p.parentEmailAddress AS parentEmail, l.lockerNumber
        FROM bookings b
        JOIN students s ON b.studentID = s.studentID
        JOIN parents p ON s.parentID = p.parentID
        JOIN lockers l ON b.lockerID = l.lockerID
        WHERE b.bookingID = ?
    ");
    $stmt->execute([$bookingID]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$booking) {
        throw new Exception("Booking not found.");
    }

    $studentID = (int)$booking['studentID'];
    $lockerID = (int)$booking['lockerID'];
    $parentID = (int)$booking['parentID'];
    $parentEmail = $booking['parentEmail'];
    $studentFullName = $booking['studentName'] . ' ' . $booking['studentSurname'];
    $lockerNumber = $booking['lockerNumber'];
    $bookingDate = date('M d, Y', strtotime($booking['bookingDate']));

    if ($action === 'approve') {
        $pdo->beginTransaction();

        // approve the booking
        $stmt = $pdo->prepare(" UPDATE bookings 
            SET status = 'approved', approvalDate = NOW(), approvedByAdminID = ?
            WHERE bookingID = ?
        ");
        $stmt->execute([$adminID, $bookingID]);

        // to mark the locker as booked
        $stmt = $pdo->prepare("UPDATE lockers SET availability = 1 WHERE lockerID = ?");
        $stmt->execute([$lockerID]);

        
       // to validate lockerID before updating
        if (empty($lockerID) || !is_numeric($lockerID) || $lockerID == 0) {
            $lockerID = null;
        }

        // to update student record
        $stmt = $pdo->prepare("UPDATE students SET lockerID = :lockerID WHERE studentID = :studentID");
        $stmt->bindParam(':lockerID', $lockerID, PDO::PARAM_INT);
        $stmt->bindParam(':studentID', $studentID, PDO::PARAM_INT);
        $stmt->execute();

        // to update waiting list
        $stmt = $pdo->prepare("UPDATE waitinglist 
            SET lockerID = ?, status = 'completed'
            WHERE studentID = ?
        ");
        $stmt->execute([$lockerID, $studentID]);

        // to delete the waiting list
        $stmt = $pdo->prepare("DELETE FROM waitinglist WHERE studentID = ?");
        $stmt->execute([$studentID]);

        
        // to mark booking as completed
        $stmt = $pdo->prepare("UPDATE bookings SET status = 'completed'
            WHERE bookingID = ? AND status = 'approved'
        ");
        $stmt->execute([$bookingID]);

        $pdo->commit();

        // to update notifications
        $stmt = $pdo->prepare("UPDATE notifications 
            SET status = 'completed' 
            WHERE parentID = ? AND type = 'Email' AND status = 'pending'
        ");
        $stmt->execute([$parentID]);

        // approval email
        $subject = "Locker Booking Approved for $studentFullName";
        $body = "
        Dear Parent,<br><br>
        Congratulations! The locker booking for <strong>{$studentFullName}</strong>
        (Locker Number: <strong>{$lockerNumber}</strong>) reserved for {$bookingDate}
        has been <strong>approved and finalized</strong>.<br><br>
        Thank you for using the Gija-Ngove Locker Booking System.<br><br>
        <strong>Best regards,</strong><br>
        Gija-Ngove Locker Booking System Administrator
        ";

    } elseif ($action === 'reject') {
        // reject booking
        $stmt = $pdo->prepare("UPDATE bookings 
            SET status = 'rejected', approvalDate = NOW(), approvedByAdminID = ?
            WHERE bookingID = ?
        ");
        $stmt->execute([$adminID, $bookingID]);

        // to update waiting list
        $stmt = $pdo->prepare("UPDATE waitinglist SET status = 'Rejected' WHERE studentID = ?");
        $stmt->execute([$studentID]);

        // to prepare rejection email
        $subject = "Locker Booking Rejected for $studentFullName";
        $body = "
        Dear Parent,<br><br>
        We regret to inform you that the locker application for
        <strong>{$studentFullName}</strong> has been <strong>rejected</strong>.<br><br>
        Please feel free to reapply at your convenience.<br><br>
        <strong>Best regards,</strong><br>
        Gija-Ngove Locker Booking System Administrator
        ";
    }

    // it send email using PHPMailer ===
    if (!empty($parentEmail)) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'vunenebasa@gmail.com';
            $mail->Password = 'gtmj ytjl gkhi ftbb'; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('vunenebasa@gmail.com', 'Administrator');
            $mail->addAddress($parentEmail);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $body;

            $mail->send();
        } catch (Exception $e) {
            error_log("Email sending failed: " . $mail->ErrorInfo);
        }
    }

    header('Location: adminDashboard.php');
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "<h2>An error occurred</h2>";
    echo "<p style='color:red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<a href='adminDashboard.php'>Return to Dashboard</a>";
    exit;

}
?>
